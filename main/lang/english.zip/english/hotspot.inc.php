<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Select";
$square = "Square";
$circle = "Elipse";
$poly = "Polygon";
$status1 = "Draw a hotspot.";
$status2_poly = "Use right-click to close the polygon.";
$status2_other = "Release the mousebutton to save the hotspot.";
$status3 = "Hotspot saved";
$exercise_status_1 = "Answer by clicking in the image below";
$exercise_status_2 = "Validate answers";
$exercise_status_3 = "Status: Question terminated";
$showUserPoints = "Show/Hide userclicks";
$showHotspots = "Show / Hide hotspots";
$labelPolyMenu = "Close polygon";
$triesleft = "Attempts left";
$exeFinished = "Now click on the button below to validate your answers.";
$nextAnswer = "Now click on: &done=done";
$delineation = "Delineation";
$labelDelineationMenu = "Close delineation";
$oar = "Area at risk";
?>