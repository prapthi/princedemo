<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "obsolete language variable";
$langMdCallingTool = "Documents";
$langTool = "Document Metadata";
$langNotInDB = "no such Links category";
$langManifestSyntax = "(syntax error in manifest file...)";
$langEmptyManifest = "(empty manifest file...)";
$langNoManifest = "(no manifest file...)";
$langNotFolder = "are not possible, it is not a folder...";
$langUploadHtt = "Upload HTT file";
$langHttFileNotFound = "New HTT file could not be opened (e.g. empty, too big)";
$langHttOk = "New HTT file has been uploaded";
$langHttNotOk = "HTT file upload has failed";
$langRemoveHtt = "Remove HTT file";
$langHttRmvOk = "HTT file has been removed";
$langHttRmvNotOk = "HTT file remove has failed";
$langImport = "Import";
$langRemove = "Remove MDEs";
$langAllRemovedFor = "All entries removed for category";
$langIndex = "Index Words";
$langTotalMDEs = "Total number of Links MD entries:";
$langMainMD = "Open Main MDE";
$langLines = "lines";
$langPlay = "Play index.php";
$langNonePossible = "No MD operations are possible";
$langOrElse = "Select a Links category";
$langWorkWith = "Work with Scorm Directory";
$langSDI = "... Scorm Directory with SD-id (and split manifest - or leave empty)";
$langRoot = "root";
$langSplitData = "Split manifests, and #MDe, if any:";
$langMffNotOk = "Manifest file replace has failed";
$langMffOk = "Manifest file has been replaced";
$langMffFileNotFound = "New manifest file could not be opened (e.g. empty, too big)";
$langUploadMff = "Replace manifest file";
?>