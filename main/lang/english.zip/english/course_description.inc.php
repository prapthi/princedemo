<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Description";
$langThisCourseDescriptionIsEmpty = "There is no course description so far.";
$langEditCourseProgram = "Create or edit a description.";
$QuestionPlan = "Help";
$langInfo2Say = "Information to give to users";
$langOuAutreTitre = "Title";
$langNewBloc = "Other";
$langAddCat = "Add a category";
$langAdd = "Add";
$langValid = "Valid";
$langBackAndForget = "Cancel";
$CourseDescriptionUpdated = "The description has been updated";
$CourseDescriptionDeleted = "Description has been deleted";
$CourseDescriptionIntro = "To create a description, click on a heading and complete the field.<br><br> Click OK to continue.";
$langSaveDescription = "Save description";
$AddCourseDescription = "Add course description";
$DescriptionUpdated = "Description updated";
$CourseDescriptions = "Course descriptions";
?>