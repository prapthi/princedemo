<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "new item added";
$TitleNotification = "Since your latest visit";
$lang_update_agenda = "event updated";
$lang_new_agenda = "event added";
$lang_update_announcements = "existing announcement updated";
$lang_new_announcements = "new announcement added";
$lang_new_document = "new document(s) added";
$lang_new_exercise = "new test enabled";
$lang_update_link = "existing link information updated";
$lang_new_link = "new link added";
$lang_new_forum_topic = "new topic added";
$lang_new_groupforum_topic = "new topic added to group forum";
$lang_new_dropbox_file = "new file received";
$lang_update_dropbox_file = "a file in your dropbox was updated";
$ForumCategoryAdded = "The forum category has been added";
$LearnpathAdded = "Course added";
$GlossaryAdded = "Added new term in the Glossary";
$QuizQuestionAdded = "Added new question in the quiz";
$QuizQuestionUpdated = "Updated new question in the Quiz";
$QuizQuestionDeleted = "Deleted new question in the Quiz";
$QuizUpdated = "Quiz updated";
$QuizAdded = "Quiz added";
$QuizDeleted = "Quiz deleted";
$DocumentInvisible = "Document invisible";
$DocumentVisible = "Document visible";
$CourseDescriptionAdded = "Course Description added";
$WikiAdded = "Wiki added";
$SurveyAdded = "Survey added";
$NotebookAdded = "Note added";
$NotebookUpdated = "Note updated";
$NotebookDeleted = "Note deleted";
$LearnpathUpdated = "Learning path updated";
?>