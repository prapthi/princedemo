<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTooBig = "You didn't choose any file to send, or it is too big";
$langLinkTarget = "Link's target";
$langSameWindow = "In the same window";
$langNewWindow = "In a new window";
$langAdded = "Added";
$langAddLink = "Add a link";
$langEditLink = "Edit link";
?>