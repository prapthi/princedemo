<?php
/*
for more information: see languages.txt in the lang folder.
*/
$Height = "Height";
$ResizingComment = "Resize the image to the following dimensions (in pixels)";
$Width = "Width";
$Resizing = "RESIZE";
$NoResizingComment = "Show all images in their original size. No resizing is done. Scrollbars will automatically appear if the image is larger than your monitor size.";
$ShowThumbnails = "Show Thumbnails";
$SetSlideshowOptions = "Gallery settings";
$SlideshowOptions = "Slideshow Options";
$NoResizing = "NO RESIZING";
$ExitSlideshow = "Exit Slideshow";
$SlideShow = "Slideshow";
$PreviousSlide = "Previous Slide";
$NextSlide = "Next image";
$ViewSlideshow = "View Slideshow";
$FirstSlide = "First slide";
$LastSlide = "Last slide";
$ResizingAuto = "AUTO RESIZE (default)";
$ResizingAutoComment = "This slideshow will resize automatically to your screen size. This is the default option.";
?>