<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Show";
$langDeactivate = "Hide";
$langInLnk = "Hidden tools and links";
$langDelLk = "Do you really want to delete this link?";
$langCourseCreate = "Create a course";
$langNameOfTheLink = "Name of the link";
$lang_main_categories_list = "Main category list";
$langCourseAdminOnly = "Teachers only";
$PlatformAdminOnly = "Portal Administrators only";
$langCombinedCourse = "Combined course";
$ToolIsNowVisible = "The tool is now visible.";
$ToolIsNowHidden = "The tool is now invisible.";
$EditLink = "Edit link";
$Blog_management = "Projects";
$Forum = "Forums";
$Course_maintenance = "Backup";
$TOOL_SURVEY = "Surveys";
$GreyIcons = "Toolbox";
$Interaction = "Interaction";
$Authoring = "Authoring";
$Administration = "Administration";
$IntroductionTextUpdated = "Intro was updated";
$IntroductionTextDeleted = "Intro was deleted";
$SessionIdentifier = "Identifier of session";
$SessionName = "Session name";
$SessionCategory = "Sessions categories";
$SessionData = "Session's data";
$TheExerciseAutoLaunchSettingIsONStudentsWillBeRedirectToAnSpecificExercise = "The exercises auto-launch feature configuration is enabled. Learners will be automatically redirected to the selected exercise.";
$TheLPAutoLaunchSettingIsONStudentsWillBeRedirectToAnSpecificLP = "The learning path auto-launch setting is ON. When learners enter this course, they will be automatically redirected to the learning path marked as auto-launch.";
$ToolSearch = "Search";
?>