<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "Please provide a subject or message";
$Inbox = "Inbox";
$Messages = "Messages";
$SendMessage = "Send message";
$NewMessage = "New message";
$ComposeMessage = "Compose message";
$DeleteSelectedMessages = "Delete selected messages";
$SelectAll = "Select all";
$DeselectAll = "Deselect all";
$ReplyToMessage = "Reply to this message";
$BackToInbox = "Back to inbox";
$MessageSentTo = "The message has been sent to";
$SendMessageTo = "Send to";
$Myself = "myself";
$From = "From";
$To = "To";
$Date = "Date";
$InvalidMessageId = "The id of the message to reply to is not valid.";
$ErrorSendingMessage = "There was an error while trying to send the message.";
$SureYouWantToDeleteSelectedMessages = "Are you sure you want to delete the selected messages?";
$SelectedMessagesDeleted = "The selected messages have been deleted";
$EnterTitle = "Please enter a title";
$TypeYourMessage = "Type your message here";
$MessageDeleted = "The message has been deleted";
$ConfirmDeleteMessage = "Are you sure you want to delete the selected message?";
$DeleteMessage = "Delete message";
$ReadMessage = "Read message";
$SendInviteMessage = "Send invitation message";
$SendMessageInvitation = "Are you sure that you wish to send these invitations ?";
$MessageTool = "Messages tool";
$WriteAMessage = "Write a message";
$AlreadyReadMessage = "Message already read";
$UnReadMessage = "Message without reading";
$MessageSent = "Message Sent";
$MailMarkSelectedAsUnread = "Mark as unread";
$MailMarkSelectedAsRead = "Mark as read";
$YouShouldWriteAMessage = "You should write a message";
$SelectedMessagesUnRead = "Selected messages have been marked as unread";
$SelectedMessagesRead = "Selected messages have been marked as read";
?>