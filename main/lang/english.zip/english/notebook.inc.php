<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "New note";
$Note = "Note";
$NoteDeleted = "Note deleted";
$NoteUpdated = "Note updated";
$NoteCreated = "Note created";
$YouMustWriteANote = "Please write a note";
$SaveNote = "Save note";
$WriteYourNoteHere = "Click here to write a new note";
$SearchByTitle = "Search by title";
$WriteTheTitleHere = "Write the title here";
$UpdateDate = "Updated";
$NoteAddNew = "Add new note in my personal notebook";
$OrderByCreationDate = "Sort by date created";
$OrderByModificationDate = "Sort by date last modified";
$OrderByTitle = "Sort by title";
$NoteTitle = "Note title";
$NoteComment = "Note details";
$NoteAdded = "Note added";
$NoteConfirmDelete = "Are you sure you want to delete this note";
$AddNote = "Create note";
$ModifyNote = "Edit my personal note";
$BackToNoteList = "Back to note list";
$NotebookManagement = "Notebook management";
$BackToNotesList = "Back to the notes list";
$NotesSortedByTitleAsc = "Notes sorted by title ascendant";
$NotesSortedByTitleDESC = "Notes sorted by title downward";
$NotesSortedByUpdateDateAsc = "Notes sorted by update date ascendant";
$NotesSortedByUpdateDateDESC = "Notes sorted by update date downward";
$NotesSortedByCreationDateAsc = "Notes sorted by creation date ascendant";
$NotesSortedByCreationDateDESC = "Notes sorted by creation date downward";
?>