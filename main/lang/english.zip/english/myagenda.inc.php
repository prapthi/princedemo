<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMyAgenda = "Personal agenda";
$langToday = "Today";
?>