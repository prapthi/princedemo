<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langExplanation = "Once you click on \"Create a course\", a course is created with a section for Tests, Project based learning, Assessments, Courses, Dropbox, Agenda and much more. Logging in as teacher provides you with editing privileges for this course.";
$langTooBig = "You didn't choose any file to send, or it is too big";
$langCouldNot = "File could not be uploaded";
$langAddPageToSite = "Add a page to the area";
$langCouldNotSendPage = "This file is not in HTML format and could not be uploaded. If you want to send non HTML documents (PDF, Word, Power Point, Video, etc.) use the Documents tool";
$langSendPage = "Page to upload";
$langPageTitleModified = "The title of the page has been modified";
$langPageAdded = "Page added";
$Choose = "Choose";
?>